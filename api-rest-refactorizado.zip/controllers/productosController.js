const productosService = require('../services/productosService');

const getProductos = (req, res) => {
    const productos = productosService.obtenerProductos();
    res.json(productos);
};

const agregarProducto = (req, res) => {
    const nuevo = productosService.agregarProducto(req.body);
    res.status(201).json(nuevo);
};

module.exports = { getProductos, agregarProducto };
