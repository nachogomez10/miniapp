# API REST - Productos (Refactorización)

## Características REST
- Usa rutas como `/productos` para acceder a recursos.
- Aplica métodos HTTP estándar: GET y POST.
- No guarda estado entre solicitudes (stateless).
- Estructura basada en recursos.

## Diferencias con el diseño anterior (3 capas)
- Se accede a través de endpoints HTTP, no funciones o vistas.
- Se usa Express.js para manejar las rutas REST.
- La lógica de negocio y de datos sigue separada (controller, service, repository).
