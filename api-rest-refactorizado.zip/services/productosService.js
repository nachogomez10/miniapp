const productosRepository = require('../repositories/productosRepository');

const obtenerProductos = () => {
    return productosRepository.getAll();
};

const agregarProducto = (producto) => {
    return productosRepository.save(producto);
};

module.exports = { obtenerProductos, agregarProducto };
