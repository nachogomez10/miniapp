const express = require('express');
const app = express();
const productosRoutes = require('./routes/productosRoutes');

app.use(express.json());
app.use('/productos', productosRoutes);

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`API REST corriendo en http://localhost:${PORT}`);
});
