const express = require('express');
const router = express.Router();
const controller = require('../controllers/productosController');

router.get('/', controller.getProductos);
router.post('/', controller.agregarProducto);

module.exports = router;
