let productos = [];

const getAll = () => productos;

const save = (producto) => {
    producto.id = productos.length + 1;
    productos.push(producto);
    return producto;
};

module.exports = { getAll, save };
