# Patrón de Diseño: Abstract Factory - Tema de Sitio Web

## Descripción

Este proyecto demuestra el uso del patrón de diseño **Abstract Factory** en un contexto de desarrollo web. Permite cambiar entre un tema claro y un tema oscuro de forma estructurada, generando componentes compatibles entre sí.

## ¿Qué problema resuelve?

Permite crear componentes (botón y barra de navegación) adecuados según el tema del sitio web sin modificar el código cliente. Así se garantiza la consistencia visual y la facilidad para agregar nuevos temas.

## ¿Cómo ejecutar el código?

1. Clona el repositorio o copia el archivo `temaFactory.js`.
2. Ejecuta el archivo en un entorno JavaScript (por ejemplo, Node.js) o copialo en la consola del navegador.
3. Modifica la instancia en el archivo:
   - Para modo oscuro: `new TemaOscuroFactory()`
   - Para modo claro: `new TemaClaroFactory()`

## Estructura del proyecto

- `TemaFactory`: Clase abstracta que define la creación de botones y navbars.
- `TemaClaroFactory` y `TemaOscuroFactory`: Fábricas concretas.
- `BotonClaro`, `BotonOscuro`, `NavbarClaro`, `NavbarOscuro`: Componentes creados por las fábricas.
- `inicializarSitio(factory)`: Función cliente que construye el sitio según la fábrica utilizada.

## Autor
[Tu nombre]
