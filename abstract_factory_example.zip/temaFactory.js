// Abstract Factory
class TemaFactory {
    crearBoton() {
        throw new Error("Este método debe ser implementado");
    }
    crearNavbar() {
        throw new Error("Este método debe ser implementado");
    }
}

// Fábrica concreta para tema claro
class TemaClaroFactory extends TemaFactory {
    crearBoton() {
        return new BotonClaro();
    }
    crearNavbar() {
        return new NavbarClaro();
    }
}

// Fábrica concreta para tema oscuro
class TemaOscuroFactory extends TemaFactory {
    crearBoton() {
        return new BotonOscuro();
    }
    crearNavbar() {
        return new NavbarOscuro();
    }
}

// Producto concreto: Botón claro
class BotonClaro {
    render() {
        console.log("Renderizando un botón CLARO");
    }
}

// Producto concreto: Botón oscuro
class BotonOscuro {
    render() {
        console.log("Renderizando un botón OSCURO");
    }
}

// Producto concreto: Navbar claro
class NavbarClaro {
    render() {
        console.log("Renderizando una barra de navegación CLARA");
    }
}

// Producto concreto: Navbar oscuro
class NavbarOscuro {
    render() {
        console.log("Renderizando una barra de navegación OSCURA");
    }
}

// Cliente que usa la Abstract Factory
function inicializarSitio(factory) {
    const boton = factory.crearBoton();
    const navbar = factory.crearNavbar();
    
    boton.render();
    navbar.render();
}

// --- Uso del patrón ---

// Supongamos que el usuario elige "modo oscuro"
const modoOscuro = new TemaOscuroFactory();
inicializarSitio(modoOscuro);

// O si elige "modo claro"
// const modoClaro = new TemaClaroFactory();
// inicializarSitio(modoClaro);
