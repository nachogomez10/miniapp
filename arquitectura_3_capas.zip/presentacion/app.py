from flask import Flask, request, jsonify
from logica.producto_logica import agregar_producto, listar_productos

app = Flask(__name__)

@app.route('/productos', methods=['POST'])
def agregar():
    data = request.json
    nombre = data.get('nombre')
    precio = data.get('precio')
    producto = agregar_producto(nombre, precio)
    return jsonify(producto), 201

@app.route('/productos', methods=['GET'])
def listar():
    return jsonify(listar_productos())

if __name__ == '__main__':
    app.run(debug=True)