productos = []

def guardar_producto(producto):
    productos.append(producto)

def obtener_productos():
    return productos