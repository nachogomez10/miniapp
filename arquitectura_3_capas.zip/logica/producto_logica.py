from datos.producto_datos import guardar_producto, obtener_productos

def agregar_producto(nombre, precio):
    producto = {'nombre': nombre, 'precio': precio}
    guardar_producto(producto)
    return producto

def listar_productos():
    return obtener_productos()