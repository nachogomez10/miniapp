# Arquitectura en Tres Capas

## Identificación de Capas

- **Capa de Presentación**: `presentacion/app.py`
- **Capa de Lógica de Negocio**: `logica/producto_logica.py`
- **Capa de Acceso a Datos**: `datos/producto_datos.py`

## Ventajas sobre versión monolítica

- Mayor claridad en la estructura del código.
- Facilita las pruebas unitarias de cada componente.
- Mejora la mantenibilidad y la escalabilidad.