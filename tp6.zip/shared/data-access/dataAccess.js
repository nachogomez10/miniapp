const fs = require('fs');
module.exports = {
  leerDatos: (file) => JSON.parse(fs.readFileSync(file))
};