module.exports = {
  ejemplo: () => 'logica ejecutada'
};