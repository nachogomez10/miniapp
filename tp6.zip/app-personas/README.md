# Aplicación de ejemplo con arquitectura de tres capas

Cada carpeta representa una aplicación con capas separadas.