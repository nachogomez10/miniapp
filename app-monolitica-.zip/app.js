const http = require('http');
const url = require('url');

let productos = [];

const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url, true);

  if (req.method === 'GET' && parsedUrl.pathname === '/listar') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(productos));
  } else if (req.method === 'POST' && parsedUrl.pathname === '/agregar') {
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
    });
    req.on('end', () => {
      const { nombre } = JSON.parse(body);
      productos.push({ nombre });
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ mensaje: `Producto agregado: ${nombre}` }));
    });
  } else {
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('Ruta no encontrada');
  }
});

server.listen(3000, () => {
  console.log('Servidor corriendo en http://localhost:3000');
});
