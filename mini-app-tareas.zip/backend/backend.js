function backend(tarea) {
  if (!tarea || tarea.trim() === "") {
    console.log("Error: La tarea no puede estar vacía.");
    return;
  }

  guardarEnBD(tarea);
  console.log(`Tarea guardada: ${tarea}`);
}
