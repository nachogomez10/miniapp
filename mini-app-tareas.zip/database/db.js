const baseDeDatos = [];

function guardarEnBD(tarea) {
  baseDeDatos.push(tarea);
}
