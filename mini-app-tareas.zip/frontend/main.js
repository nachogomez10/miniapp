function agregarTarea() {
  const tarea = document.getElementById("tareaInput").value;
  backend(tarea);
}

document.body.innerHTML = `
  <input type="text" id="tareaInput" placeholder="Escribí una tarea">
  <button onclick="agregarTarea()">Agregar</button>
`;
